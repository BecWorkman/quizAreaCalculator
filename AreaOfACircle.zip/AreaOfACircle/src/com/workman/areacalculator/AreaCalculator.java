package com.workman.areacalculator;

public class AreaCalculator {
	
	 private static double area = 0;
	 private static double radius = 14;
	 private static double pi = 3.14;

	public static void main(String[] args) {
		calcAreaOfCircle(pi, radius);
		displayArea(area);

	}
	public static void calcAreaOfCircle(double x, double y){
		area = x * (y * y);
	}
	
	public static void displayArea(double a) {
		System.out.println(a);
	}

}
